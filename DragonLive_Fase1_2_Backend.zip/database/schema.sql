
CREATE TABLE usuarios(id SERIAL PRIMARY KEY,nome VARCHAR(100),email VARCHAR(100));
CREATE TABLE videos(id SERIAL PRIMARY KEY,usuario_id INT,video_url TEXT);
CREATE TABLE curtidas(id SERIAL PRIMARY KEY,usuario_id INT,video_id INT);
CREATE TABLE comentarios(id SERIAL PRIMARY KEY,video_id INT,comentario TEXT);
CREATE TABLE seguidores(id SERIAL PRIMARY KEY,seguidor_id INT,seguido_id INT);
