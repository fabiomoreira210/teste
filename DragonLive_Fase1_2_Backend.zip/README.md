# DragonLive Fase 1.2
Backend expandido com PostgreSQL, JWT, Multer e Docker.
