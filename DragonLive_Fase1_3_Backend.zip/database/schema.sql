
CREATE TABLE usuarios(
 id SERIAL PRIMARY KEY,
 nome VARCHAR(100),
 email VARCHAR(100) UNIQUE,
 senha VARCHAR(255),
 role VARCHAR(20) DEFAULT 'user'
);

CREATE TABLE videos(
 id SERIAL PRIMARY KEY,
 usuario_id INT,
 descricao TEXT,
 video_url TEXT,
 created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE comentarios(
 id SERIAL PRIMARY KEY,
 video_id INT,
 usuario_id INT,
 comentario TEXT
);

CREATE TABLE curtidas(
 id SERIAL PRIMARY KEY,
 usuario_id INT,
 video_id INT
);
