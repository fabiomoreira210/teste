# DragonLive Fase 1.3
Backend avançado com estrutura para API REST, JWT, Swagger e Admin.
