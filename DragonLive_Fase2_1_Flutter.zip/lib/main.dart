
import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

void main() => runApp(const DragonLiveApp());

class DragonLiveApp extends StatelessWidget {
  const DragonLiveApp({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(home: LoginScreen());
  }
}
