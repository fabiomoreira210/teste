
const express=require('express');
const app=express();
app.use(express.json());
app.get('/',(req,res)=>res.json({status:'DragonLive Online'}));
app.listen(3000);
