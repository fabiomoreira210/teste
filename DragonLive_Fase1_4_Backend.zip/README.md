# DragonLive Fase 1.4
Backend preparado para lives, chat, moedas e ranking.
