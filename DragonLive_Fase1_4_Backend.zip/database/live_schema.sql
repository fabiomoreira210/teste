
CREATE TABLE lives(
 id SERIAL PRIMARY KEY,
 usuario_id INT,
 titulo VARCHAR(255),
 status VARCHAR(50),
 espectadores INT DEFAULT 0
);

CREATE TABLE mensagens_live(
 id SERIAL PRIMARY KEY,
 live_id INT,
 usuario_id INT,
 mensagem TEXT
);

CREATE TABLE dragon_coins(
 id SERIAL PRIMARY KEY,
 usuario_id INT,
 saldo INT DEFAULT 0
);

CREATE TABLE presentes(
 id SERIAL PRIMARY KEY,
 nome VARCHAR(100),
 valor INT
);
