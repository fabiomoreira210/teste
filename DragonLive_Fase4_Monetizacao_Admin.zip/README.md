# DragonLive Fase 4
Monetização, VIP, PIX e Painel Administrativo.
