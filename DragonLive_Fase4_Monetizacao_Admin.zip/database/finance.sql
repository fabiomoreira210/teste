
CREATE TABLE vip_planos(
 id SERIAL PRIMARY KEY,
 nome VARCHAR(100),
 valor DECIMAL(10,2)
);

CREATE TABLE saques(
 id SERIAL PRIMARY KEY,
 usuario_id INT,
 valor DECIMAL(10,2),
 status VARCHAR(30)
);

CREATE TABLE denuncias(
 id SERIAL PRIMARY KEY,
 usuario_id INT,
 motivo TEXT
);
