# DragonLive Fase 2.2
Autenticação JWT, feed, comentários e seguidores.
