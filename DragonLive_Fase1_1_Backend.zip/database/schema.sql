CREATE TABLE usuarios(
id SERIAL PRIMARY KEY,
nome VARCHAR(100),
usuario VARCHAR(50),
email VARCHAR(100) UNIQUE,
senha VARCHAR(255)
);

CREATE TABLE videos(
id SERIAL PRIMARY KEY,
usuario_id INT,
descricao TEXT,
video_url TEXT,
curtidas INT DEFAULT 0
);

CREATE TABLE comentarios(
id SERIAL PRIMARY KEY,
video_id INT,
usuario_id INT,
comentario TEXT
);

CREATE TABLE seguidores(
id SERIAL PRIMARY KEY,
seguidor_id INT,
seguido_id INT
);
