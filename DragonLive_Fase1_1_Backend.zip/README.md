# DragonLive Fase 1.1
Cadastro, Login JWT, estrutura para vídeos e seguidores.