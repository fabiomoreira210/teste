const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');

exports.register=async(req,res)=>{
 const hash=await bcrypt.hash(req.body.senha,10);
 res.json({nome:req.body.nome,email:req.body.email,senha:hash});
};

exports.login=async(req,res)=>{
 const token=jwt.sign({id:1},process.env.JWT_SECRET,{expiresIn:'30d'});
 res.json({token});
};
