# DragonLive Fase 3
Lives em tempo real, chat, moedas e presentes.
