
CREATE TABLE lives(
 id SERIAL PRIMARY KEY,
 usuario_id INT,
 titulo VARCHAR(255),
 status VARCHAR(20)
);

CREATE TABLE presentes(
 id SERIAL PRIMARY KEY,
 nome VARCHAR(100),
 valor INT
);

CREATE TABLE dragon_coins(
 id SERIAL PRIMARY KEY,
 usuario_id INT,
 saldo INT DEFAULT 0
);
