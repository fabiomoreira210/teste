#!/bin/bash
pg_dump dragonlive > backup.sql