
# Checklist de Lançamento
- API online
- Banco configurado
- SSL ativo
- Backup ativo
- Monitoramento ativo
- Aplicativos publicados
